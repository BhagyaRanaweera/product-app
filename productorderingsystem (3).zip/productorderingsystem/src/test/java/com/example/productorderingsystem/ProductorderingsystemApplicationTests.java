package com.example.productorderingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductorderingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
