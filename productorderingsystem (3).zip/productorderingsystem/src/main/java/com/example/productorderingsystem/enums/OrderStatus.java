package com.example.productorderingsystem.enums;

public enum OrderStatus {
    PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED, RETURNED
}