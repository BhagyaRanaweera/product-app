package com.example.productorderingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductorderingsystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(ProductorderingsystemApplication.class, args);
	}

}
