package com.example.productorderingsystem.service.interf;

import com.example.productorderingsystem.dto.AddressDto;
import com.example.productorderingsystem.dto.Response;
public interface AddressService {
    Response saveAndUpdateAddress(AddressDto addressDto);
}