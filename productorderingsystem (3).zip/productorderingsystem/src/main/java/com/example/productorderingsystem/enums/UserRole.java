package com.example.productorderingsystem.enums;

public enum UserRole {
    ADMIN,
    USER

}
