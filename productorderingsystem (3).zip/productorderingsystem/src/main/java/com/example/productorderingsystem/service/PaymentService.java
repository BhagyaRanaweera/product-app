// package com.example.productorderingsystem.service;

// import com.stripe.Stripe;
// import com.stripe.exception.StripeException;
// import com.stripe.model.checkout.Session;
// import org.springframework.stereotype.Service;

// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;

// @Service
// public class PaymentService {

//     public PaymentService() {
//         Stripe.apiKey = "sk_test_51QH4Q1HpZQPWXTXAVxQ8BdlMhikOsOi2BmXJxhK1eQFudky3VXFJGFgcjtWrnNTNSkg0spSEZOILR7xag1gv9MuK00dj2o7UnR"; // Replace with your Stripe secret key
//     }

//     public Map<String, String> createCheckoutSession(String productName, Long quantity, Double price) {
//         try {
//             Map<String, Object> params = new HashMap<>();
//             params.put("success_url", "http://localhost:3000/success");
//             params.put("cancel_url", "http://localhost:3000/cancel");
//             params.put("payment_method_types", List.of("card"));

//             Map<String, Object> lineItem = new HashMap<>();
//             lineItem.put("price_data", Map.of(
//                 "currency", "usd",
//                 "product_data", Map.of("name", productName),
//                 "unit_amount", (int) (price * 100)
//             ));
//             lineItem.put("quantity", quantity);

//             params.put("line_items", List.of(lineItem));
//             params.put("mode", "payment");

//             Session session = Session.create(params);

//             return Map.of("sessionId", session.getId(), "url", session.getUrl());
//         } catch (StripeException e) {
//             throw new RuntimeException("Failed to create Stripe session: " + e.getMessage(), e);
//         }
//     }
// }
package com.example.productorderingsystem.service;

import com.example.productorderingsystem.entity.Payment;
import com.example.productorderingsystem.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    public Optional<Payment> findPaymentById(String id) {
        return paymentRepository.findById(id);
    }
}
